Action()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	web_reg_save_param("C_Usersession","LB=name=\"userSession\" value=\"","RB=\"/>",LAST);
	
	web_reg_find("Fail=NotFound","savecount=Homepage_count","Text=Web Tours",LAST);
	lr_start_transaction("HomePage");
	
	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	if(lr_eval_string("{HomePage_count}")==0)
	   {
	   	lr_end_transaction("HomePage",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("HomePage",LR_PASS);
	   }
	   
	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_think_time(42);
	web_reg_find("Fail=NotFound","savecount=Loginpage_count","Text={P_Username}",LAST);
	
	lr_start_transaction("TC_01_Login");

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={C_Usersession}", ENDITEM, 
		"Name=username", "Value={P_Username}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		"Name=login.x", "Value=29", ENDITEM, 
		"Name=login.y", "Value=10", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);
	if(lr_eval_string("{LoginPage_count}")==0)
	   {
	   	lr_end_transaction("TC_01_Login",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("TC_01_Login",LR_PASS);
	   }
	   

	

	lr_think_time(15);

	web_reg_find("Fail=NotFound","savecount=FindFlightpage_count","Text=Find Flight",LAST);
	
	lr_start_transaction("TC_02_FindFlight");
	web_reg_save_param_ex("ParamName=C_DepartCity","LB=\">","RB=</option>","Ordinal=all",LAST);
	
	
	web_url("Search Flights Button", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	if(lr_eval_string("{FindFlightPage_count}")==0)
	   {
	   	lr_end_transaction("TC_02_FindFlight",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("TC_02_FindFlight",LR_PASS);
	   }
	   

	lr_think_time(7);
	
	lr_save_string(lr_paramarr_random("C_DepartCity"),"C_DepartureCity");
	lr_save_string(lr_paramarr_random("C_DepartCity"),"C_ArrivalCity");
	while(lr_eval_string("C_Departurecity")==lr_eval_string("C_ArrivalCity")){
	lr_save_string(lr_paramarr_random("C_DepartCity"),"C_ArrivalCity");	
	}
	
	web_reg_save_param("C_OutboundFlight","LB=name=\"outboundFlight\" value=\"","RB=\"",LAST);
	
	web_reg_find("Fail=NotFound","savecount=Findflight2page_count","Text=Flight departing from",LAST);
	
	lr_start_transaction("TC_03");
	
	
	
	web_submit_data("reservations.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value={C_DepartureCity}", ENDITEM, 
		"Name=departDate", "Value=04/25/2023", ENDITEM, 
		"Name=arrive", "Value={C_ArrivalCity}", ENDITEM, 
		"Name=returnDate", "Value=04/26/2023", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=55", ENDITEM, 
		"Name=findFlights.y", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);
	if(lr_eval_string("{Findflight2page_count}")==0)
	   {
	   	lr_end_transaction("TC_03",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("TC_03",LR_PASS);
	   }
	   
	web_reg_find("Fail=NotFound","savecount=paymentpage_count","Text=Payment Details",LAST);
	
	   lr_start_transaction("TC_04_FindFlight");

	web_submit_data("reservations.pl_2", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value={C_OutboundFlight}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=reserveFlights.x", "Value=39", ENDITEM, 
		"Name=reserveFlights.y", "Value=9", ENDITEM, 
		LAST);
	   if(lr_eval_string("{paymentpage_count}")==0)
	   {
	   	lr_end_transaction("TC_04_FindFlight",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("TC_04_FindFlight",LR_PASS);
	   }

	

	lr_think_time(26);
	
	web_reg_find("Fail=NotFound","savecount=invoicepage_count","Text=Thank you for booking through Web Tours.",LAST);

	lr_start_transaction("TC_05_PaymentDetails");

	web_submit_data("reservations.pl_3", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value={P_FirstName}", ENDITEM, 
		"Name=lastName", "Value={P_LastName}", ENDITEM, 
		"Name=address1", "Value={Address1}", ENDITEM, 
		"Name=address2", "Value={Address2}", ENDITEM, 
		"Name=pass1", "Value={P_Pass1}", ENDITEM, 
		"Name=creditCard", "Value={P_Creditcardnum}", ENDITEM, 
		"Name=expDate", "Value={P_Expdate}", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=outboundFlight", "Value={C_OutboundFlight}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=43", ENDITEM, 
		"Name=buyFlights.y", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);
	if(lr_eval_string("{invoicepage_count}")==0)
	   {
	   	lr_end_transaction("TC_05_PaymentDetails",LR_FAIL);
	
	   }
	   else
	   {
	   	lr_end_transaction("TC_05_PaymentDetails",LR_PASS);
	   }


	

	return 0;
}