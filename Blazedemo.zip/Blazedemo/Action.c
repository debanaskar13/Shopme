Action()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_reg_save_param_ex("ParamName=C_Port","LB=<option value=\"","RB=\">","Ordinal=all",LAST);
	
	web_url("{P_Url}", 
		"URL=https://{P_Url}/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);
	
	
	
	
	lr_save_string(lr_paramarr_random("C_Port"),"C_formPort");
	
	lr_save_string(lr_paramarr_random("C_Port"),"C_toPort");
	
	while(lr_eval_string("C_formPort") == lr_eval_string("C_toPort")){
		lr_save_string(lr_paramarr_random("C_Port"),"C_toPort");
	}
	
	
	
	
	web_submit_data("reserve.php", 
		"Action=https://{P_Url}/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{P_Url}/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_formPort}", ENDITEM, 
		"Name=toPort", "Value={C_toPort}", ENDITEM, 
		LAST);

	web_add_cookie("keen={%22uuid%22:%22dcabe9b8-9513-4b86-9ebc-839e8370f8ab%22%2C%22initialReferrer%22:%22https://{P_Url}/%22}; DOMAIN={P_Url}");

	web_submit_data("purchase.php", 
		"Action=https://{P_Url}/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{P_Url}/reserve.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=12", ENDITEM, 
		"Name=price", "Value=765.32", ENDITEM, 
		"Name=airline", "Value=Virgin America", ENDITEM, 
		"Name=fromPort", "Value={C_formPort}", ENDITEM, 
		"Name=toPort", "Value={C_toPort}", ENDITEM, 
		LAST);

	web_submit_data("confirmation.php", 
		"Action=https://{P_Url}/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{P_Url}/purchase.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value={P_name}", ENDITEM, 
		"Name=address", "Value={P_address}", ENDITEM, 
		"Name=city", "Value={P_city}", ENDITEM, 
		"Name=state", "Value={P_state}", ENDITEM, 
		"Name=zipCode", "Value={P_zipcode}", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value={P_creditCardNo}", ENDITEM, 
		"Name=creditCardMonth", "Value={P_creditCardMonth}", ENDITEM, 
		"Name=creditCardYear", "Value={P_creditCardYear}", ENDITEM, 
		"Name=nameOnCard", "Value={P_creditCardName}", ENDITEM, 
		LAST);

	return 0;
}