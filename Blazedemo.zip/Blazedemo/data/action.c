Action()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("prodperfect_session={%22session_uuid%22:%22c08238a4-b362-415d-bbf1-7ef65d157b33%22}; DOMAIN=blazedemo.com");

	web_add_cookie("keen={%22uuid%22:%22dcabe9b8-9513-4b86-9ebc-839e8370f8ab%22%2C%22initialReferrer%22:null}; DOMAIN=blazedemo.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("blazedemo.com", 
		"URL=https://blazedemo.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value=Paris", ENDITEM, 
		"Name=toPort", "Value=Buenos Aires", ENDITEM, 
		LAST);

	web_add_cookie("keen={%22uuid%22:%22dcabe9b8-9513-4b86-9ebc-839e8370f8ab%22%2C%22initialReferrer%22:%22https://blazedemo.com/%22}; DOMAIN=blazedemo.com");

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=12", ENDITEM, 
		"Name=price", "Value=765.32", ENDITEM, 
		"Name=airline", "Value=Virgin America", ENDITEM, 
		"Name=fromPort", "Value=Paris", ENDITEM, 
		"Name=toPort", "Value=Buenos Aires", ENDITEM, 
		LAST);

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=test", ENDITEM, 
		"Name=address", "Value=test", ENDITEM, 
		"Name=city", "Value=test", ENDITEM, 
		"Name=state", "Value=test", ENDITEM, 
		"Name=zipCode", "Value=12345", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=1234567890", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2028", ENDITEM, 
		"Name=nameOnCard", "Value=John Smith", ENDITEM, 
		LAST);

	return 0;
}